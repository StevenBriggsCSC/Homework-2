# Steven Briggs
# Homework 2 Part 2 Part A
# Date Due: February 7, 2019


def partA(content):
    content = [x.strip() for x in content]
    letterCount = 0
    index = 0
    occurred_index = 0
    found = False
    for line in content:
        letterCount += line.count('s')
        letterCount += line.count('S')
        letterCount += line.count('b')
        letterCount += line.count('B')

        if ((('s' and 'b') in line) or ('S' and 'B' in line)) and not found:
            occurred_index = index
            found = True

        index += 1
    print("Uppercase and lowercase initials occur", letterCount , "times in the text file.")
    print("Intials occur in the same line on line", occurred_index + 1)


def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input) as f:
            content = f.readlines()
        f.close()
    except:
        print("There was an error opening a file")
    else:
        partA(content)


main()
