# Steven Briggs
# Homework 2 Middle
# Date Due: February 7, 2019

def find_middle(flag, lines):
    s = ' '
    if flag == "Y" or flag == "y":
        top = int(input("Enter what line to skip to "))
        bottom = int(input("Enter how many lines to omit at the end "))
        if len(lines) <= bottom + top:
            print(s.join(lines))
        else:
            print(s.join(lines[top:-bottom]))
    else:
        if len(lines) <= 10:
            print(s.join(lines))
        else:
            print(s.join(lines[5:-5]))

def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input, 'r') as text_file:
            lines = text_file.readlines()
            lines = [x.strip('\n') for x in lines]
            text_file.close()
    except:
        print("The file could not be found")
    else:
        flag = input("Enter custom amount of lines to skip at the top and bottom? (Y, N) ")
        find_middle(flag, lines)
    text_file.close()
main()