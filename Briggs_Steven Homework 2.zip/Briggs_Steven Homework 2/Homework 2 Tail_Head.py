# Steven Briggs
# Homework 2 Tail_Head
# Date Due: February 7, 2019


def tail_head(flag, lines):
    s = ' '
    if flag == "Y" or flag == "y":
        line_skip = int(input("Enter number of lines to display to pull from head and tail of file"))
        if len(lines) <= line_skip * 2:
            print(s.join(lines))
        else:
            print(s.join(lines[-line_skip:]), s.join(lines[:line_skip]))
    else:
        if len(lines) <= 10:
            print(s.join(lines))
        else:
            print(s.join(lines[-5:]), s.join(lines[:5]))

def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input, 'r') as text_file:
            lines = text_file.readlines()
            lines = [x.strip('\n') for x in lines]
            text_file.close()
    except:
        print("The file could not be found")
    else:
        flag = input("Enter custom amount of lines instead of default lines? (Y, N) ")
        tail_head(flag, lines)
main()