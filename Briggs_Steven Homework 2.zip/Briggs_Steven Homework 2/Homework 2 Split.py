# Steven Briggs
# Homework 2 Split
# Date Due: February 7, 2019

import string


def split(lines):
    s = ' '
    i = 0
    j = 0
    local_lines = lines
    while len(local_lines) > 0:
        if len(local_lines) > 1000:
            f = open('x' + string.ascii_lowercase[i] + string.ascii_lowercase[j] + '.ext', 'w+')
            # print
            f.writelines(s.join(local_lines[:1000]))
            print("Saved to file " + 'x' + string.ascii_lowercase[i] + string.ascii_lowercase[j] + '.ext')
            local_lines = local_lines[1000:]
            j += 1
            if j > 25:
                i += 1
                j = 0
        else:
            f = open('x' + string.ascii_lowercase[i] + string.ascii_lowercase[j] + '.ext', 'w+')
            f.writelines(s.join(local_lines))
            print("Saved to file " + 'x' + string.ascii_lowercase[i] + string.ascii_lowercase[j] + '.ext')
            local_lines.clear()


def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input, 'r') as text_file:
            lines = text_file.readlines()
            lines = [x.strip('\n') for x in lines]
            text_file.close()
    except:
        print("The file could not be found")
    else:
        split(lines)

main()