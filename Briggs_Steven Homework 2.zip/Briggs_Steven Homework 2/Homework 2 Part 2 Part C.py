# Steven Briggs
# Homework 2 Part 2 Part B
# Date Due: February 7, 2019


def partC(content):
    content = [x.strip() for x in content]
    my_dict = {}

    for line in content:
        word_by_word_list = line.split()
        for word in word_by_word_list:
            if 's' in word.lower():
                if 'b' in word.lower():
                    if word in my_dict:
                        my_dict[word] += 1
                    else:
                        my_dict[word] = 1

    with open("appearance_of_initials.txt", "w+") as f:
        f.write(str(my_dict))
        f.write("\n")

def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input) as f:
            content = f.readlines()
        f.close()
    except:
        print("There was an error opening a file")
    else:
        partC(content)


main()