# Steven Briggs
# Homework 2 Part 2 Part B
# Date Due: February 7, 2019


def partB(content):
    s = ' '
    content = [x.strip() for x in content]
    word_by_word_list = []

    f = open("sorted_lines.txt", "w+")
    for line in content:
            word_by_word_list = line.split()
            word_by_word_list.sort()
            f.write(s.join(word_by_word_list))
            f.write('\n')
            word_by_word_list.clear()
    f.close()


def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input) as f:
            content = f.readlines()
        f.close()
    except:
        print("There was an error opening a file")
    else:
        partB(content)


main()