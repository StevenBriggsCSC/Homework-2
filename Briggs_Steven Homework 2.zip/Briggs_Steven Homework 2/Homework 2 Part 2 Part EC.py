# Steven Briggs
# Homework 2 Part 2 Part B
# Date Due: February 7, 2019

def partEC(content):
    content = [x.strip() for x in content]
    my_dict = {}
    index = 0
    letter_list = []
    for line in content:
        word_by_word_list = line.split()
        for word in word_by_word_list:
            for letter in word:
                letter_list.append(letter)

    for i in range(len(letter_list)):
        if letter_list[i].lower() == 's':
            if i + 1 >= len(letter_list):
                break
            elif letter_list[i + 1] in my_dict:
                my_dict[letter_list[i + 1]] += 1
            else:
                my_dict[letter_list[i + 1]] = 1

    with open("following_s.txt", "w+") as f:
        f.write(str(my_dict))
        f.write("\n")


def main():
    user_input = input("Enter name of text file ")
    try:
        with open(user_input) as f:
            content = f.readlines()
        f.close()
    except:
        print("There was an error opening a file")
    else:
        partEC(content)

main()